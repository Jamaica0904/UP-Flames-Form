package com.example.afinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Registration extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
    }

    public void submit(View v){
        Toast.makeText(getApplicationContext(), "You have registered successfully! Please wait for the confirmation via email.", Toast.LENGTH_LONG).show();
        Intent i = new Intent(getApplicationContext(),Login.class);
        startActivity(i);
        finish();
    }
}
